# INSTRUÇÕES PARA APRESENTAÇÃO DE PROVAS DIGITAIS EM JUÍZO
*(Guia Prático para o Advogado de Defesa)*

As provas obtidas no histórico do WhatsApp e nos comprovantes bancários são robustas, mas sua aceitação pelo juiz depende de sua correta introdução no processo, evitando alegações de adulteração ou nulidade pela parte contrária. Abaixo estão as diretrizes recomendadas para garantir a validade jurídica das provas digitais, com fulcro no Código de Processo Civil (CPC) e na jurisprudência do Tribunal Superior do Trabalho (TST).

---

## 1. Ata Notarial (Artigo 384 do CPC) - O Meio Mais Seguro
A ata notarial é o instrumento público pelo qual o tabelião de um Cartório de Notas atesta a existência e o conteúdo de fatos digitais (como conversas de WhatsApp, áudios e fotos). Ela possui **fé pública** e sua força probatória é quase inabalável.

* **O que registrar prioritariamente:**
  O advogado deve solicitar ao tabelião a transcrição e registro visual das seguintes mensagens e arquivos da conversa com o Reclamante:
  1. **Mensagem de 22/07/2024 (10:38:03 e 19:40:02):** Em que o Reclamante pede explicitamente para não registrar a carteira para reverter o valor dos encargos na compra do carro Fox 2008 do tio.
  2. **Conversa de 06/07/2025 (das 11:49 às 22:11):** Em que as partes fecham o acerto rescisório de R$ 12.852,44, o Reclamante confirma a retirada dos valores físicos ("Ok peguei lá...") e o envio dos comprovantes Pix e da foto do termo de rescisão assinado.
  3. **A foto assinada da rescisão (06/07/2025, 21:50:20):** Foto do termo impresso e assinado pelo Reclamante, enviada pelo próprio na conversa.

* **Recomendação técnica:**
  O tabelião deve acessar a conversa diretamente do aparelho celular do Reclamado ou através do WhatsApp Web, verificando o número de telefone do Reclamante (21 96018-2156) e registrando os metadados (como o ID da transação do Pix e o nome do arquivo da foto da rescisão).

---

## 2. Preservação do Arquivo ZIP Original (Cadeia de Custódia)
O arquivo ZIP exportado diretamente do aplicativo WhatsApp (`WhatsApp Chat - Marcio Novo Celular.zip`) contém o banco de dados das mensagens em formato texto (`_chat.txt`) e todas as mídias (fotos, vídeos, áudios `.opus` e comprovantes em PDF) com os nomes originais padronizados pelo aplicativo.

* **O que fazer:**
  1. **Manter o arquivo ZIP intocado:** O arquivo ZIP original possui assinaturas de data/hora de criação e hashes de integridade. Ele deve ser preservado em ambiente seguro (nuvem ou HD externo) para o caso de uma eventual perícia técnica.
  2. **Juntada em mídia eletrônica:** Se o sistema PJe da Vara do Trabalho local não comportar arquivos grandes (o ZIP tem cerca de 90 MB), o advogado deve peticionar informando que possui o backup original da mídia à disposição do juízo e requerer a juntada por meio de link de nuvem seguro (ex: Google Drive, OneDrive) ou depósito de pendrive na secretaria da Vara.

---

## 3. Metadados e Validação da Foto da Rescisão Assinada
A foto da rescisão assinada (`00004486-PHOTO-2025-07-06-21-50-20.jpg`) é a prova definitiva do pagamento e da quitação das verbas. 

* **Para o Advogado demonstrar em juízo:**
  1. A imagem foi enviada pelo próprio Reclamante na conversa, conforme registrado no log de chat.
  2. A data de modificação/criação do arquivo de imagem coincide perfeitamente com a data escrita à mão no documento (06 de julho de 2025).
  3. O advogado pode extrair os metadados EXIF da imagem (usando propriedades do arquivo ou ferramentas de metadados) para comprovar o modelo de câmera/celular que tirou a foto, a resolução e a ausência de edição de imagem (Photoshop ou manipulações afins).

---

## 4. Cruzamento de Dados e Conciliação com Extrato Bancário
Para corroborar a veracidade dos comprovantes de Pix anexados à conversa do WhatsApp:

* **O que fazer:**
  1. Solicitar ao Reclamado (Thiago) o extrato bancário oficial em formato PDF da conta de origem (Bogados Padaria e Confeitaria - CNPJ 31.269.546/0001-76) referente ao dia **06/07/2025**.
  2. Demonstrar em juízo que o débito de R$ 1.000,00 coincide exatamente com o ID de transação (`E165015552025070701118dc909bcc34`) constante no comprovante de Pix enviado na conversa (`00004494-...pdf`).
  3. Fazer o mesmo cruzamento para outros comprovantes de Pix de adiantamentos semanais (PG) mencionados na conversa, comprovando que todos os pagamentos descritos ocorreram de fato.

---

## 5. Plataformas de Coleta de Provas Digitais (Alternativa Viável)
Se o custo de uma Ata Notarial em cartório for elevado, o advogado pode utilizar plataformas online de registro de provas digitais com validade jurídica reconhecida pelos tribunais, tais como a **Verifact** ou **OriginalMy**.

* **Como funciona:**
  Essas plataformas auditam o navegador e gravam a navegação no WhatsApp Web ou no e-mail do cliente, gerando um relatório técnico com certificação digital ICP-Brasil, carimbo de tempo do Observatório Nacional e metadados completos que impedem a contestação de autenticidade pela parte contrária.
