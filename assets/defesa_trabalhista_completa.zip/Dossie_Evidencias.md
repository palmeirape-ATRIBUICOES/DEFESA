# DOSSIÊ DE EVIDÊNCIAS E PROVAS DIGITAIS
**Reclamante**: Marcio Jone Franklin de Paula  
**Reclamados**: Thiago Palmeira Barbosa e Mana Panificadora e Comércio Ltda  
**Processo nº**: 0100545-34.2026.5.01.0222 (Vara do Trabalho de Nova Iguaçu/RJ)

Este dossiê organiza as conversas do WhatsApp (arquivo [_chat.txt](file:///C:/Users/thiag/Downloads/WhatsApp%20Chat%20-%20Marcio%20Novo%20Celular.zip)), fotos e comprovantes bancários em tópicos de defesa para rebater sistematicamente cada alegação da petição inicial.

---

## 1. Do Vínculo Empregatício e da Ausência de Registro (CTPS)
### A Alegação do Reclamante:
Alega que trabalhou sem registro em carteira por culpa exclusiva e má-fé dos Reclamados, pleiteando indenização por Danos Morais de **R$ 10.000,00** pela "clandestinidade" do vínculo.

### As Provas Reais (WhatsApp):
* **O Reclamante pediu expressamente para NÃO ter a carteira assinada**:
  No dia **22/07/2024** (linhas 3146 e 3178 da conversa), Marcio propôs receber o valor correspondente aos encargos trabalhistas (INSS/FGTS) em mãos para conseguir comprar um carro Fox 2008 de seu tio, parcelado em R$ 700,00, comprometendo-se a pagar a Previdência de forma autônoma.
  > **Transcrição Exata (22/07/2024, 10:38:03 e 19:40:02):**  
  > *`Marcio Novo Celular: Deixa eu te fazer uma pergunta quanto vc pagaria dr encargos pra assinar minha carteira ?? E que meu tio que me vender um carro (2008) sem entrada parcelas de $700 e dependendo de quanto for esse encargos se vc pudesse me dar em maos em interaria ( e eu faria uma autonomia e pagaria a parte ) se vc puder fazer esse esquema me ajudaria muito`*

* **Ajuste de Valores sobre a Carteira**:
  Em **06/07/2025** (linha 5083), Marcio confirma a negociação envolvendo a "ajuda na carteira" para o abatimento no acerto rescisório:
  > **Transcrição Exata (06/07/2025, 14:05:14):**  
  > *`Marcio Novo Celular: Se me recordo bem do carro foi $5,000.00 e Maia $500,00 da ajuda na carteira ...`*
  > *`Thiago Palmeira: A carteira eu nem contei`*

### Tese de Defesa:
Inexistência de má-fé patronal ou dano moral. O próprio trabalhador solicitou e se beneficiou da informalidade contratual temporária para obter vantagens financeiras imediatas (compra de veículo próprio). Aplicação do princípio da boa-fé objetiva (proibição do comportamento contraditório - *venire contra factum proprium*).

---

## 2. Da Quitação Integral das Verbas Rescisórias
### A Alegação do Reclamante:
Alega que foi demitido em 24/06/2025 sem justa causa e que jamais recebeu qualquer valor referente às verbas rescisórias, aviso prévio, férias ou FGTS (pleiteando R$ 186.939,89 em verbas brutas e reflexos).

### As Provas Reais (WhatsApp e Documentos):
* **Acordo e Assinatura do Recibo de Quitação**:
  Em **06/07/2025**, Marcio assinou e enviou a foto do documento formalizado de **Rescisão** dando quitação das verbas rescisórias calculadas no montante de **R$ 12.852,44**, abrangendo salário, férias vencidas e proporcionais, 13º salário, aviso prévio indenizado de 6 dias e FGTS.
  * **Documento Assinado**: [00004486-PHOTO-2025-07-06-21-50-20.jpg](file:///C:/Users/thiag/.gemini/antigravity/scratch/whatsapp_extract/00004486-PHOTO-2025-07-06-21-50-20.jpg) (Foto enviada por Marcio na conversa em 06/07/2025, às 21:50:20).
  * **Minuta de Cálculo Enviada**: [00004443-Rescisaaao MARCIO JONE com FGTS 2025.pdf (1).pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/whatsapp_extract/00004443-Rescisaaao%20MARCIO%20JONE%20com%20FGTS%202025.pdf%20(1).pdf) (PDF enviado por Thiago em 04/07/2025, contendo o demonstrativo exato assinado posteriormente).

* **Deduções Acertadas e Pagamento Efetivado**:
  A conversa demonstra que o acerto final envolveu o abatimento de R$ 5.000,00 adiantados para a compra do carro e outros pequenos adiantamentos. O saldo devedor restante foi de R$ 1.000,00, pago imediatamente via Pix.
  > **Transcrição Exata (06/07/2025, 15:17:23):**  
  > *`Thiago Palmeira: Tenho que te mandar 1000 então certo ? Mando no Pix mesmo?`*  
  > *`Marcio Novo Celular: Isso`*  
  > *`Marcio Novo Celular: 2196018 2156 [Chave Pix]`*
  * **Comprovante de Pagamento do Saldo**: [00004494-276F0EAF-A53F-4FA5-B7F0-F782D18D9392.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/whatsapp_extract/00004494-276F0EAF-A53F-4FA5-B7F0-F782D18D9392.pdf) (Transferência Pix de R$ 1.000,00 de Bogados Padaria e Confeitaria para Marcio Jone Franklin de Paula, realizada em **06/07/2025 às 22:11:13**).

### Tese de Defesa:
Quitação e transação extrajudicial válida. O Reclamante mentiu em juízo ao afirmar que nada recebeu. Deve ser reconhecida a compensação/dedução integral dos valores quitados no recibo assinado e no Pix sob pena de enriquecimento ilícito (*bis in idem*), e aplicada a pena por Litigância de Má-Fé (art. 80, II, do CPC).

---

## 3. Da Jornada de Trabalho, Horas Extras e Intervalo
### A Alegação do Reclamante:
Alega que trabalhava de segunda a sábado, de forma ininterrupta, das 06:00 às 15:00, sem gozo de intervalo intrajornada para descanso ou alimentação, pleiteando R$ 26.634,73 em horas extras e R$ 13.694,69 em intervalo suprimido.

### As Provas Reais (WhatsApp):
* **Flexibilidade de Jornada e "Biscates" na Parte da Manhã**:
  No dia **06/02/2024** (linha 1798), Marcio solicitou autorização para mudar seu horário de entrada para as **09:00** a fim de realizar serviços externos das 06:00 às 08:00, trabalhando na padaria apenas das 09:00 às 14:00 (uma jornada de **5 horas diárias**).
  > **Transcrição Exata (06/02/2024, 15:43:23):**  
  > *`Marcio Novo Celular: Vou fazer um biscatinho aqui perto de casa de 6 as oito posso chegar lá umas 9:00 da manhã eu fico até 14:00 Pode ser ?? e todo domingo`*

* **Trabalhos e Compromissos Particulares nos Dias de Folga**:
  O Reclamante realizava serviços de drywall em suas folgas e ausentava-se para resolver questões particulares (audiências de divórcio, etc.), comprovando que não havia a jornada exaustiva descrita.
  > **Transcrição Exata (28/07/2023, 16:18:21 - linha 420):**  
  > *`Marcio Novo Celular: terça que é minha folga domingo tenho um compromisso (rebaixar um teto no draywall)...`*
  > **Transcrição Exata (03/04/2024, 11:46:26 - linha 2109):**  
  > *`Marcio Novo Celular: Em relação a fazer o salgado vou folgar quarta as 8:00 vou na audiência e de lá vou pra sua casa...`*

* **Divisão de Trabalho com Ajudantes e Outros Padeiros**:
  O Reclamante trabalhava em conjunto com outros profissionais (Moacir, Rafael), descaracterizando a tese de labor solitário e ininterrupto.
  > **Transcrição Exata (28/10/2023, 22:21:16 - linha 1081):**  
  > *`Marcio Novo Celular: Boa noite Thiago fiz 42 grades e pedi pro Moacir fazer mais 10 ok`*

### Tese de Defesa:
Inexistência de horas extras habituais ou supressão de intervalo. O reclamante possuía ampla liberdade de horário, executava serviços particulares ("biscates") durante o período em que alega estar trabalhando na padaria e contava com o auxílio constante de outros funcionários na produção.

---

## 4. Do Acúmulo de Função (Padeiro, Confeiteiro e Salgadeiro)
### A Alegação do Reclamante:
Alega que acumulou as funções de salgadeiro e confeiteiro por falta de pessoal na padaria, exigindo um acréscimo salarial de 40% (totalizando R$ 34.026,15).

### As Provas Reais (WhatsApp):
* **Havia Confeiteiros Contratados**:
  Os registros de contatos na conversa provam a contratação de pessoal especializado para a confeitaria:
  * **Carlos Confeiteiro** (Contato enviado em 08/07/2024 - linha 2863).
  * **Kayti Confeiteira** (Contato enviado em 25/07/2024 - linha 3251).
  * Diálogo no dia **25/07/2024 (linha 3242)**: Marcio lamenta que uma candidata é "só confeiteira", o que demonstra que havia vagas e profissionais específicos para a função.

* **Volume Irrisório de Salgados**:
  A produção de salgados era residual e eventual, além de ser auxiliada pelos ajudantes. No dia **28/10/2024**, Thiago determinou o limite máximo de salgados diários, comprovando a baixa exigência:
  > **Transcrição Exata (28/10/2024, 21:48:53):**  
  > *`Thiago Palmeira: Não fazer mais do que 20 salgados por dia.`*

### Tese de Defesa:
Improcedência do pedido. As atividades de confeitaria e panificação são afins e inserem-se no âmbito do contrato de trabalho geral (art. 456, parágrafo único, da CLT). Além disso, a empresa contava com equipe própria para estas especialidades e o volume de salgados produzidos era insignificante, sem acarretar sobrecarga de trabalho.

---

## 5. Do Adicional de Insalubridade (Calor e Frio)
### A Alegação do Reclamante:
Reivindica adicional de insalubridade em grau máximo (R$ 20.525,44), alegando que trabalhava exposto ao calor excessivo dos fornos e ao frio extremo ao adentrar em "câmaras frias" sem o uso de Equipamentos de Proteção Individual (EPI).

### As Provas Reais (WhatsApp):
* **Inexistência de "Câmara Fria" (Congelamento/Resfriamento Industrial)**:
  Toda menção à "câmara" na conversa refere-se à **câmara de fermentação do pão** (armário climatizado ou com temperatura controlada para o crescimento da massa), e não a câmaras frigoríficas industriais de armazenamento de congelados onde há risco por frio.
  * *Exemplo (06/04/2025):* Marcio pergunta sobre a farinha e Thiago responde: "*Acho que tem atrás da câmara*" (linha 4886).
  * Não há registros de reclamação ou menção de entrada em locais de frio extremo no chat. Apenas referências ao funcionamento da "câmara de pão" e manutenção dos fornos.

### Tese de Defesa:
Improcedência. A "câmara de pão" é um equipamento de fermentação/crescimento de massa de panificação, não gerando exposição ao frio nos termos da NR-15 da Portaria nº 3.214/78 do MTE. A verificação da temperatura real e dos níveis de calor dos fornos deve ser remetida à perícia técnica, restando impugnada a alegação genérica do autor.
