# DOSSIÊ DE EVIDÊNCIAS E PROVAS DIGITAIS
**Reclamante**: Marcio Jone Franklin de Paula  
**Reclamados**: Thiago Palmeira Barbosa e Mana Panificadora e Comércio Ltda  
**Processo nº**: 0100545-34.2026.5.01.0222 (Vara do Trabalho de Nova Iguaçu/RJ)

Este dossiê organiza as conversas do WhatsApp (arquivo [_chat.txt](file:///C:/Users/thiag/Downloads/WhatsApp%20Chat%20-%20Marcio%20Novo%20Celular.zip)), fotos e comprovantes bancários em tópicos de defesa para rebater sistematicamente cada alegação da petição inicial.

---

## 1. Do Vínculo Empregatício e da Ausência de Registro (CTPS)
### A Alegação do Reclamante:
Alega que trabalhou sem registro em carteira por culpa exclusiva e má-fé dos Reclamados, pleiteando indenização por Danos Morais de **R$ 10.000,00** pela "clandestinidade" do vínculo.

### As Provas Reais (WhatsApp):
* **O Reclamante pediu expressamente para NÃO ter a carteira assinada**:
  No dia **22/07/2024** (linhas 3146 e 3178 da conversa), Marcio propôs receber o valor correspondente aos encargos trabalhistas (INSS/FGTS) em mãos para conseguir comprar um carro Fox 2008 de seu tio, parcelado em R$ 700,00, comprometendo-se a pagar a Previdência de forma autônoma.
  > **Transcrição Exata (22/07/2024, 10:38:03 e 19:40:02):**  
  > *`Marcio Novo Celular: Deixa eu te fazer uma pergunta quanto vc pagaria dr encargos pra assinar minha carteira ?? E que meu tio que me vender um carro (2008) sem entrada parcelas de $700 e dependendo de quanto for esse encargos se vc pudesse me dar em maos em interaria ( e eu faria uma autonomia e pagaria a parte ) se vc puder fazer esse esquema me ajudaria muito`*

* **Ajuste de Valores sobre a Carteira**:
  Em **06/07/2025** (linha 5083), Marcio confirma a negociação envolvendo a "ajuda na carteira" para o abatimento no acerto rescisório:
  > **Transcrição Exata (06/07/2025, 14:05:14):**  
  > *`Marcio Novo Celular: Se me recordo bem do carro foi $5,000.00 e Maia $500,00 da ajuda na carteira ...`*
  > *`Thiago Palmeira: A carteira eu nem contei`*

### Tese de Defesa:
Inexistência de má-fé patronal ou dano moral. O próprio trabalhador solicitou e se beneficiou da informalidade contratual temporária para obter vantagens financeiras imediatas (compra de veículo próprio). Aplicação do princípio da boa-fé objetiva (proibição do comportamento contraditório - *venire contra factum proprium*).

---

## 2. Da RescisÃ£o Contratual, QuitaÃ§Ã£o Inicial e Acerto Complementar
### A AlegaÃ§Ã£o do Reclamante:
Alega que foi demitido sem receber nenhum valor rescisÃ³rio, aviso prÃ©vio ou FGTS, pretendendo a condenaÃ§Ã£o das reclamadas ao pagamento de R$ 186.939,89.

### As Provas Reais (WhatsApp e Comprovantes):

#### Fase 1: QuitaÃ§Ã£o Inicial (06/07/2025)
* **Documento Assinado**: [rescisao_assinada.jpg](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Recibo_Rescisao_Assinado_Marcio.jpg) (Foto enviada por Marcio na conversa em 06/07/2025 Ã s 21:50:20, contendo a assinatura do termo com valor de **R$ 12.852,44**).
* **Pix de Saldo Restante**: [comprovante_pix.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Final_R1000.pdf) (Pix de R$ 1.000,00 enviado por Thiago em 06/07/2025 Ã s 22:11:13 da conta jurÃ­dica Bogados Padaria, ID de transaÃ§Ã£o E165015552025070701118dc909bcc34).

#### Fase 2: ReclamaÃ§Ã£o dos CÃ¡lculos (07/07/2025)
* O Reclamante contesta as contas enviadas no dia anterior, alegando que as fÃ©rias deveriam usar a base de R$ 2.200,00 e que faltavam a multa do FGTS (40%) e o INSS:
  > **TranscriÃ§Ã£o Exata (07/07/2025, 15:12:35):**  
  > *Marcio Novo Celular: Quem fez essa conta ?? NÃ£o colocou a multa dos 40% as fÃ©rias ao valor de $ 2000 era pra atualizar no salÃ¡rio vigente  O INSS vc pediu pra colocar??*

#### Fase 3: Ajuste Complementar e QuitaÃ§Ã£o Final (23/08/2025)
* Thiago pede para Marcio ver o valor das diferenÃ§as. Marcio envia os novos cÃ¡lculos e propÃµe o valor de **R$ 2.600,00** para liquidar tudo definitivamente:
  > **TranscriÃ§Ã£o Exata (23/08/2025, 13:33:19):**  
  > *Thiago Palmeira: VÃª o valor aÃ­ pra mim*  
  > *Marcio Novo Celular: [Envia fotos dos cÃ¡lculos 00004549 a 00004553]*  
  > *Marcio Novo Celular: IrmÃ£o ..faz assim poe  e ficamos quiti ...pode ser ??*  
  > *Thiago Palmeira: Fechado*  
  > *Thiago Palmeira: Vou te mandar aÃ­ agora*  
  > *Marcio Novo Celular: Vlwww*  
  > *Thiago Palmeira: [Envia comprovante do Pix de R$ 2.600,00]*  
  > *Marcio Novo Celular: Sem problemas irmÃ£o ..no que precisar ao meu alcance sÃ³ chamar ðŸ‘ðŸ‘*
* **Pix de QuitaÃ§Ã£o Complementar**: [Comprovante_Pix_Complementar_R2600.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Complementar_R2600.pdf) (TransferÃªncia Pix de R$ 2.600,00 de Bogados Padaria e Confeitaria para Marcio Jone Franklin de Paula realizada em **23/08/2025 Ã s 13:58:40**, ID de transaÃ§Ã£o BCD8D84D-69AC-410E-9DA4-77C066BBB209).
* **Imagem Comprovante WhatsApp**: [Recibo_Pix_Complementar_R2600.jpg](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Recibo_Pix_Complementar_R2600.jpg) (Foto do recibo Stone enviada no chat).

### Tese de Defesa:
QuitaÃ§Ã£o integral e transaÃ§Ã£o extrajudicial civil perfeita. O Reclamante omitiu dolosamente dois pagamentos em sua inicial e o termo assinado. Os R$ 2.600,00 adicionais quitam todas as reclamaÃ§Ãµes por ele apresentadas (fÃ©rias com base de R$ 2.200,00, multa do FGTS e INSS), inexistindo qualquer saldo credor.
## 3. Da Jornada de Trabalho, Horas Extras e Intervalo
### A AlegaÃ§Ã£o do Reclamante:
Alega que trabalhava de segunda a sÃ¡bado, de forma ininterrupta, das 06:00 Ã s 15:00, sem gozo de intervalo intrajornada para descanso ou alimentaÃ§Ã£o, pleiteando R$ 26.634,73 em horas extras e R$ 13.694,69 em intervalo suprimido.

### A Realidade dos Fatos:
* **HorÃ¡rio Livre e ProduÃ§Ã£o-Tarefa ("Acabou, vai embora")**:
  O Reclamante trabalhava sob o regime de tarefa/produÃ§Ã£o diÃ¡ria, possuindo total flexibilidade e horÃ¡rio livre para chegar e sair. Geralmente chegava entre **07:30 e 08:00** (frequentemente pegando carona com o colega Rafael, que trabalhava no mesmo turno). A saÃ­da ocorria assim que a produÃ§Ã£o do dia fosse concluÃ­da. Sendo uma padaria de pequeno porte, em **99% dos casos a produÃ§Ã£o era finalizada antes das 14:00**, resultando em uma jornada diÃ¡ria real de cerca de 6 a 6,5 horas (muito inferior ao limite legal de 8 horas).
* **AusÃªncia de RestriÃ§Ã£o para Lanches e Intervalos**:
  Sempre houve tempo livre e farto disponÃ­vel para fazer intervalos e lanches de forma irrestrita, sem qualquer limite ou controle punitivo.
* **Turno Ãšnico e Testemunha Ocular**:
  Havia apenas um turno de trabalho (o turno da manhÃ£). O Sr. Rafael trabalhava exatamente no mesmo horÃ¡rio do Reclamante, vivenciou toda essa rotina flexÃ­vel e comparecerÃ¡ em juÃ­zo como testemunha ocular para comprovar esses horÃ¡rios e a liberdade de lanches.

### As Provas Reais (WhatsApp):
* **Flexibilidade de Jornada e "Biscates" na Parte da ManhÃ£**:
  No dia **06/02/2024** (linha 1798), Marcio solicitou autorizaÃ§Ã£o para mudar seu horÃ¡rio de entrada para as **09:00** a fim de realizar serviÃ§os externos das 06:00 Ã s 08:00, trabalhando na padaria apenas das 09:00 Ã s 14:00 (uma jornada de **5 horas diÃ¡rias**).
  > **TranscriÃ§o Exata (06/02/2024, 15:43:23):**  
  > *Marcio Novo Celular: Vou fazer um biscatinho aqui perto de casa de 6 as oito posso chegar lÃ¡ umas 9:00 da manhÃ£ eu fico atÃ© 14:00 Pode ser ?? e todo domingo*

* **Trabalhos e Compromissos Particulares nos Dias de Folga**:
  O Reclamante realizava serviÃ§os de drywall em suas folgas e ausentava-se para resolver questÃµes particulares (audiÃªncias de divÃ³rcio, etc.), comprovando que nÃ£o havia a jornada exaustiva descrita.
  > **TranscriÃ§o Exata (28/07/2023, 16:18:21 - linha 420):**  
  > *Marcio Novo Celular: terÃ§a que Ã© minha folga domingo tenho um compromisso (rebaixar um teto no draywall)...*
  > **TranscriÃ§o Exata (03/04/2024, 11:46:26 - linha 2109):**  
  > *Marcio Novo Celular: Em relaÃ§Ã£o a fazer o salgado vou folgar quarta as 8:00 vou na audiÃªncia e de lÃ¡ vou pra sua casa...*

* **Diviso de Trabalho com Ajudantes e Outros Padeiros**:
  O Reclamante trabalhava em conjunto com outros profissionais (Moacir, Rafael), descaracterizando a tese de labor solitÃ¡rio e ininterrupto.
  > **TranscriÃ§o Exata (28/10/2023, 22:21:16 - linha 1081):**  
  > *Marcio Novo Celular: Boa noite Thiago fiz 42 grades e pedi pro Moacir fazer mais 10 ok*

### Tese de Defesa:
InexistÃªncia de horas extras habituais ou supresso de intervalo. O reclamante possuÃ­a ampla liberdade de horÃ¡rio, trabalhava por tarefa diÃ¡ria sendo dispensado logo apÃ³s o tÃ©rmino da produÃ§Ã£o (geralmente antes das 14h), realizava lanches sem limites e contava com o auxÃ­lio constante de outros funcionÃ¡rios na produÃ§Ã£o, tudo atestado pela testemunha ocular Rafael.
## 4. Do Acúmulo de Função (Padeiro, Confeiteiro e Salgadeiro)
### A Alegação do Reclamante:
Alega que acumulou as funções de salgadeiro e confeiteiro por falta de pessoal na padaria, exigindo um acréscimo salarial de 40% (totalizando R$ 34.026,15).

### As Provas Reais (WhatsApp e Fatos Físicos):
* **Inexistência de Confeitaria na Padaria**:
  A padaria não comercializa bolos confeitados decorados ou artísticos (com pasta americana). Apenas produzia bolos simples utilizando **pré-mistura comercial em pó**, uma tarefa simples que consiste apenas em misturar o pó pronto e assar.
  * *Como provar:* Notas fiscais e histórico de compras dos fornecedores contendo as compras das pré-misturas para bolos.
  * No dia **21/07/2024**, Thiago menciona no WhatsApp: *"Quero começar a fazer bolo de marcação. Esses bolo de pré mistura são secos. Tu tem receita"* (linhas 3140-3142), o que confirma que apenas trabalhavam com misturas prontas secas de bolo.

* **Salgados Residuais (Aproveitamento de Sobras)**:
  A produção de salgados era eventual e servia para **aproveitar pedaços de frios** (mortadela, queijo e presunto) que não podiam mais ser fatiados na máquina e seriam descartados.
  * O volume diário de salgados (cachorro-quente e hambúrgueres de massa de pão) limitava-se a **menos de 20 unidades por dia**, que frequentemente sobravam devido ao baixo movimento e à produção em excesso do reclamante, gerando desperdício.
  * Diálogo no dia **28/10/2024 (linha 3924)**: Thiago Palmeira orienta limitando a produção: *"Não fazer mais do que 20 salgados por dia"*, o que comprova o controle do baixo volume.

* **Trabalho em Equipe (Dois Padeiros)**:
  O Reclamante trabalhava em conjunto com outro padeiro/ajudante na produção de 4 sacos de farinha de trigo diários (pequeno porte). Ele trabalhou inicialmente com o Sr. Moacir e, depois, com o Sr. Rafael (que atuará como testemunha).
  * Diálogo em **22/07/2024 (linha 3163)**: Marcio diz sobre as folgas e a divisão da escala de folgas da equipe: *"Vou mudar as folgas pra quarta e quinta fica melhor pra produzir ok eu vou folgar quinta e ele quarta ele me perguntou sobre o PG como vai ser..."*

### Tese de Defesa:
Improcedência do pedido. As atividades de panificação, confeitaria de misturas e fabricação residual de salgados assados básicos são afins, complementares e compatíveis com a função de Padeiro, conforme art. 456 da CLT. A escala produtiva (4 sacos de farinha/dia) e o trabalho em equipe (2 padeiros) comprovam a total ausência de sobrecarga ou desvio de função.

---

## 5. Do Adicional de Insalubridade (Calor e Frio)
### A AlegaÃ§Ã£o do Reclamante:
Reivindica adicional de insalubridade em grau mÃ¡ximo (R$ 20.525,44), alegando que trabalhava exposto ao calor excessivo dos fornos e ao frio extremo ao adentrar em "cÃ¢maras frias" sem o uso de Equipamentos de ProteÃ§o Individual (EPI).

### A Realidade dos Fatos:
* **Fornecimento e Uso de EPIs (Luvas TÃ©rmicas)**:
  Para o manuseio das assadeiras e bandejas de pÃ£es retiradas dos fornos quentes, os funcionÃ¡rios sempre utilizaram **luvas tÃ©rmicas de proteÃ§Ã£o contra calor**, neutralizando eventuais riscos decorrentes da temperatura elevada.
* **InexistÃªncia Absoluta de CÃ¢mara Fria**:
  O estabelecimento comercial nÃ£o possui cÃ¢mara fria de congelamento ou resfriamento industrial. A Ãºnica cÃ¢mara existente no local Ã© uma **cÃ¢mara de fermentaÃ§Ã£o controlada** (armÃ¡rio climatizado em temperatura ambiente ou aquecimento/resfriamento leve unicamente para crescimento biolÃ³gico da massa do pÃ£o), a qual funciona sem qualquer temperatura extrema que gere risco por frio ou choque tÃ©rmico.

### As Provas Reais (WhatsApp):
* **InexistÃªncia de "CÃ¢mara Fria" (Congelamento/Resfriamento Industrial)**:
  Toda menÃ§o Ã  "cÃ¢mara" na conversa refere-se Ã  **cÃ¢mara de fermentaÃ§o do po** (armÃ¡rio climatizado ou com temperatura controlada para o crescimento da massa), e nÃ£o a cÃ¢maras frigorÃ­ficas industriais de armazenamento de congelados onde hÃ¡ risco por frio.
  * *Exemplo (06/04/2025):* Marcio pergunta sobre a farinha e Thiago responde: "*Acho que tem atrÃ¡s da cÃ¢mara*" (linha 4886).
  * NÃ£o hÃ¡ registros de reclamaÃ§o ou menÃ§o de entrada em locais de frio extremo no chat. Apenas referÃªncias ao funcionamento da "cÃ¢mara de pÃ³" e manutenÃ§o dos fornos.

### Tese de Defesa:
ImprocedÃªncia. A padaria nÃ£o possui cÃ¢mara frigorÃ­fica de congelados, mas apenas armÃ¡rio climatizado de fermentaÃ§Ã£o, afastando insalubridade por frio. Para o manuseio dos fornos quentes, os padeiros utilizavam regularmente luvas tÃ©rmicas protetivas. Requer-se a perÃ­cia tÃ©cnica nos termos do art. 195, Â§2Âº, da CLT para comprovar a eficÃ¡cia dos EPIs e a ausÃªncia de agentes insalubres.

## A Alegação do Reclamante:
Reivindica adicional de insalubridade em grau máximo (R$ 20.525,44), alegando que trabalhava exposto ao calor excessivo dos fornos e ao frio extremo ao adentrar em "câmaras frias" sem o uso de Equipamentos de Proteção Individual (EPI).

### As Provas Reais (WhatsApp):
* **Inexistência de "Câmara Fria" (Congelamento/Resfriamento Industrial)**:
  Toda menção à "câmara" na conversa refere-se à **câmara de fermentação do pão** (armário climatizado ou com temperatura controlada para o crescimento da massa), e não a câmaras frigoríficas industriais de armazenamento de congelados onde há risco por frio.
  * *Exemplo (06/04/2025):* Marcio pergunta sobre a farinha e Thiago responde: "*Acho que tem atrás da câmara*" (linha 4886).
  * Não há registros de reclamação ou menção de entrada em locais de frio extremo no chat. Apenas referências ao funcionamento da "câmara de pão" e manutenção dos fornos.

### Tese de Defesa:
Improcedência. A "câmara de pão" é um equipamento de fermentação/crescimento de massa de panificação, não gerando exposição ao frio nos termos da NR-15 da Portaria nº 3.214/78 do MTE. A verificação da temperatura real e dos níveis de calor dos fornos deve ser remetida à perícia técnica, restando impugnada a alegação genérica do autor.
