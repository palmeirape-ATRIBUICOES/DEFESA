# DOSSIÊ DE EVIDÊNCIAS E PROVAS DIGITAIS
**Reclamante**: Marcio Jone Franklin de Paula  
**Reclamados**: Thiago Palémeira Barbosa e Mana Panificadora e Comércio Ltda  
**Processo nº**: 0100545-34.2026.5.01.0222 (Vara do Trabalho de Nova Iguaçu/RJ)

Este dossiê organiza as conversas do WhatsApp (arquivo [_chat.txt](file:///C:/Users/thiag/Downloads/WhatsApp%20Chat%20-%20Marcio%20Novo%20Celular.zip)), fotos e comprovantes bancários em tópicos de defesa para rebater sistematicamente cada alegação da petição inicial.

---

## 1. Do Vínculo Empregatício e da Ausência de Registro (CTPS)
### A Alegação do Reclamante:
Alega que trabalhou sem registro em carteira por culpa exclusiva e má-fé dos Reclamados, pleiteando indenização por Danos Morais de **R$ 10.000,00** pela "clandestinidade" do vínculo.

### As Provas Reais (WhatsApp):
* **O Reclamante pediu expressamente para NÃO ter a carteira assinada**:
  No dia **22/07/2024** (linhas 3146 e 3178 da conversa), Marcio propôs receber o valor correspondente aos encargos trabalhistas (INSS/FGTS) em mãos para conseguir comprar um carro Fox 2008 de seu tio, parcelado em R$ 700,00, comprometendo-se a pagar a Previdência de forma autônoma.
  > **Transcrição Exata (22/07/2024, 10:38:03 e 19:40:02):**  
  > *`Marcio Novo Celular: Deixa eu te fazer uma pergunta quanto vc pagaria dr encargos pra assinar minha carteira ?? E que meu tio que me vender um carro (2008) sem entrada parcelas de $700 e dependendo de quanto for esse encargos se vc pudesse me dar em maos em interaria ( e eu faria uma autonomia e pagaria a parte ) se vc puder fazer esse esquema me ajudaria muito`*

* **Ajuste de Valores sobre a Carteira**:
  Em **06/07/2025** (linha 5083), Marcio confirma a negociação envolvendo a "ajuda na carteira" para o abatimento no acerto rescisório:
  > **Transcrição Exata (06/07/2025, 14:05:14):**  
  > *`Marcio Novo Celular: Se me recordo bem do carro foi $5,000.00 e Maia $500,00 da ajuda na carteira ...`*
  > *`Thiago Palémeira: A carteira eu nem contei`*

### Tese de Defesa:
Inexistência de má-fé patronal ou dano moral. O próprio trabalhador solicitou e se beneficiou da informalidade contratual temporária para obter vantagens financeiras imediatas (compra de veículo próprio). Aplicação do princípio da boa-fé objetiva (proibição do comportamento contraditório - *venire contra factum proprium*).

---

## 2. Da Rescisão Contratual, Quitação Inicial e Acerto Complementar
### A Alegação do Reclamante:
Alega que foi demitido sem receber nenhum valor rescisório, aviso prévio ou FGTS, pretendendo a condenação das reclamadas ao pagamento de R$ 186.939,89.

### As Provas Reais (WhatsApp e Comprovantes):

#### Fase 1: Quitação Inicial (06/07/2025)
* **Documento Assinado**: [rrescisao_assinada.jpg](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Recibo_Rescisao_Assinado_Marcio.jpg) (Foto enviada por Marcio na conversa em 06/07/2025 às 21:50:20, contendo a assinatura do termo com valor de **R$ 12.852,44**).
* **Pix de Saldo Restante**: [comprovante_pix.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Final_R1000.pdf) (Pix de R$ 1.000,00 enviado por Thiago em 06/07/2025 às 22:11:13 da conta jurídica Bogados Padaria, ID de transação E165015552025070701118dc909bcc34).

#### Fase 2: Reclamação dos Cálculos (07/07/2025)
* O Reclamante contesta as contas enviadas no dia anterior, alegando que as férias deveriam usar a base de R$ 2.200,00 e que faltavam a multa do FGTS (40%) e o INSS:
  > **Transcrição Exata (07/07/2025, 15:12:35):**  
  > *Marcio Novo Celular: Quem fez essa conta ?? Não colocou a multa dos 40% as férias ao valor de $ 2000 era pra atualizar no salário vigente  O INSS vc pediu pra colocar??*

#### Fase 3: Ajuste Complementar e Quitação Final (23/08/2025)
* Thiago pede para Marcio ver o valor das diferenças. Marcio envia os novos cálculos e propõe o valor de **R$ 2.600,00** para liquidar tudo definitivamente:
  > **Transcrição Exata (23/08/2025, 13:33:19):**  
  > *Thiago Palémeira: Vê o valor aí pra mim*  
  > *Marcio Novo Celular: [Envia fotos dos cálculos 00004549 a 00004553]*  
  > *Marcio Novo Celular: Irmão ..faz assim poe  e ficamos quiti ...pode ser ??*  
  > *Thiago Palémeira: Fechado*  
  > *Thiago Palémeira: Vou te mandar aí agora*  
  > *Marcio Novo Celular: Vlwww*  
  > *Thiago Palémeira: [Envia comprovante do Pix de R$ 2.600,00]*  
  > *Marcio Novo Celular: Sem problemas irmão ..no que precisar ao meu alcance só chamar ðŸ‘ðŸ‘*
* **Pix de Quitação Complementar**: [Comprovante_Pix_Complementar_R2600.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Complementar_R2600.pdf) (Transferência Pix de R$ 2.600,00 de Bogados Padaria e Confeitaria para Marcio Jone Franklin de Paula realizada em **23/08/2025 às 13:58:40**, ID de transação BCD8D84D-69AC-410E-9DA4-77C066BBB209).
* **Imagem Comprovante WhatsApp**: [Recibo_Pix_Complementar_R2600.jpg](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Recibo_Pix_Complementar_R2600.jpg) (Foto do recibo Stone enviada no chat).

### Tese de Defesa:
Quitação integral e transação extrajudicial civil perfeita. O Reclamante omitiu dolosamente dois pagamentos em sua inicial e o termo assinado. Os R$ 2.600,00 adicionais quitam todas as reclamações por ele apresentadas (férias com base de R$ 2.200,00, multa do FGTS e INSS), inexistindo qualquer saldo credor.
## 3. Da Remuneração, Pagamentos Semanais via PJ e Inexistência de Confusão Patrimonial
### A Alegação do Reclamante:
Alega que recebia salário de R$ 2.200,00 acrescido de R$ 150,00 "por fora" pagos diretamente pelo segundo Reclamado (Thiago, pãessoa física), pretendendo a desconsideração da personalidade jurídica e a responsabilização pãessoal/solidária do sócio.

### A Realidade dos Fatos:
* **Salário Pactuado e Reajustes**: O salário inicial era de R$ 2.000,00 (pagos na proporção semanal de R$ 500,00). Posteriormente, o salário foi reajustado para R$ 2.200,00 (pagos na proporção semanal de R$ 550,00).
* **Ausência de Pagamento por Pãessoa Física**: Todos os comprovantes bancários revelam que as transferências eram realizadas de forma exclusiva pela conta bancária da pãessoa jurídica **BOGADOS PADARIA E CONFEITARIA (CNPJ 31.269.546/0001-76)**. Não há nenhuma transação originada de conta física do sócio Thiago Palémeira Barbosa.
* **Vantagem Financeira do Calendário Semanal**: O pagamento semanal (52 semanas/ano) garantiu ao Reclamante o recebimento de 4 semanas adicionais de salário por ano, funcionando como gratificação extra espontânea (14º salário), sem prejuízo do 13º salário integral.

### As Provas Reais (Histórico Completo de 16 Comprovantes Semanais):
  * Pix 1 (24/06/2023): [Comprovante_Pix_Semanal_R500_2023_06_24.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_06_24.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 24/06/2023).
  * Pix 2 (01/07/2023): [Comprovante_Pix_Semanal_R500_2023_07_01.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_07_01.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 01/07/2023).
  * Pix 3 (08/07/2023): [Comprovante_Pix_Semanal_R500_2023_07_08.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_07_08.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 08/07/2023).
  * Pix 4 (15/07/2023): [Comprovante_Pix_Semanal_R500_2023_07_15.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_07_15.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 15/07/2023).
  * Pix 5 (12/08/2023): [Comprovante_Pix_Semanal_R500_2023_08_12.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_08_12.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 12/08/2023).
  * Pix 6 (21/08/2023): [Comprovante_Pix_Semanal_R500_2023_08_21.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_08_21.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 21/08/2023).
  * Pix 7 (02/09/2023): [Comprovante_Pix_Semanal_R500_2023_09_02.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_09_02.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 02/09/2023).
  * Pix 8 (17/09/2023): [Comprovante_Pix_Semanal_R500_2023_09_17.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_09_17.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 17/09/2023).
  * Pix 9 (15/10/2023): [Comprovante_Pix_Semanal_R500_2023_10_15.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2023_10_15.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 15/10/2023).
  * Pix 10 (08/01/2024): [Comprovante_Pix_Semanal_R500_2024_01_08.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2024_01_08.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 08/01/2024).
  * Pix 11 (19/03/2024): [Comprovante_Pix_Semanal_R500_2024_03_19.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R500_2024_03_19.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 500,00 em 19/03/2024).
  * Pix 12 (22/06/2024): [Comprovante_Pix_Semanal_R550_2024_06_22.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R550_2024_06_22.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 550,00 em 22/06/2024).
  * Pix 13 (29/06/2024): [Comprovante_Pix_Semanal_R550_2024_06_29.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R550_2024_06_29.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 550,00 em 29/06/2024).
  * Pix 14 (06/07/2024): [Comprovante_Pix_Semanal_R550_2024_07_06.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R550_2024_07_06.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 550,00 em 06/07/2024).
  * Pix 15 (05/10/2024): [Comprovante_Pix_Semanal_R550_2024_10_05.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R550_2024_10_05.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 550,00 em 05/10/2024).
  * Pix 16 (22/02/2025): [Comprovante_Pix_Semanal_R550_2025_02_22.pdf](file:///C:/Users/thiag/.gemini/antigravity/scratch/Entrega_Advogada/Comprovante_Pix_Semanal_R550_2025_02_22.pdf) (Transferência Stone de Bogados Padaria para o Reclamante, no valor de R$ 550,00 em 22/02/2025).

### Tese de Defesa:
Improcedência absoluta da responsabilidade pãessoal solidária do sócio Thiago Palémeira Barbosa. Todos os pagamentos salariais semanais foram efetuados via conta jurídica do estabelecimento comercial, afastando qualquer hipótese de confusão patrimonial.

---

## 4. Da Jornada de Trabalho, Horas Extras e Intervalo
### A Alegação do Reclamante:
Alega que trabalhava de segunda a sábado, de forma ininterrupta, das 06:00 às 15:00, sem gozo de intervalo intrajornada para descanso ou alimentação, pleiteando R$ 26.634,73 em horas extras e R$ 13.694,69 em intervalo suprimido.

### A Realidade dos Fatos:
* **Horário Livre e Produção-Tarefa ("Acabou, vai embora")**:
  O Reclamante trabalhava sob o regime de tarefa/produção diária, possuindo total flexibilidade e horário livre para chegar e sair. Geralémente chegava entre **07:30 e 08:00** (frequentemente pegando carona com o colega Rafael, que trabalhava no mesmo turno). A saída ocorria assim que a produção do dia fosse concluída. Sendo uma padaria de pequeno porte, em **99% dos casos a produção era finalizada antes das 14:00**, resultando em uma jornada diária real de cerca de 6 a 6,5 horas (muito inferior ao limite legal de 8 horas).
* **Ausência de Restrição para Lanches e Intervalos**:
  Sempre houve tempo livre e farto disponível para fazer intervalos e lanches de forma irrestrita, sem qualquer limite ou controle punitivo.
* **Turno Único e Testemunha Ocular**:
  Havia apenas um turno de trabalho (o turno da manhã). O Sr. Rafael trabalhava exatamente no mesmo horário do Reclamante, vivenciou toda essa rotina flexível e comparecerá em juízo como testemunha ocular para comprovar esses horários e a liberdade de lanches.

### As Provas Reais (WhatsApp):
* **Flexibilidade de Jornada e "Biscates" na Parte da Manhã**:
  No dia **06/02/2024** (linha 1798), Marcio solicitou autorização para mudar seu horário de entrada para as **09:00** a fim de realizar serviços externos das 06:00 às 08:00, trabalhando na padaria apenas das 09:00 às 14:00 (uma jornada de **5 horas diárias**).
  > **Transcriço Exata (06/02/2024, 15:43:23):**  
  > *Marcio Novo Celular: Vou fazer um biscatinho aqui perto de casa de 6 as oito posso chegar lá umas 9:00 da manhã eu fico até 14:00 Pode ser ?? e todo domingo*

* **Trabalhos e Compromissos Particulares nos Dias de Folga**:
  O Reclamante realizava serviços de drywall em suas folgas e ausentava-se para resolver questões particulares (audiências de divórcio, etc.), comprovando que não havia a jornada exaustiva descrita.
  > **Transcriço Exata (28/07/2023, 16:18:21 - linha 420):**  
  > *Marcio Novo Celular: terça que é minha folga domingo tenho um compromisso (rebaixar um teto no draywall)...*
  > **Transcriço Exata (03/04/2024, 11:46:26 - linha 2109):**  
  > *Marcio Novo Celular: Em relação a fazer o salgado vou folgar quarta as 8:00 vou na audiência e de lá vou pra sua casa...*

* **Diviso de Trabalho com Ajudantes e Outros Padeiros**:
  O Reclamante trabalhava em conjunto com outros profissionais (Moacir, Rafael), descaracterizando a tese de labor solitário e ininterrupto.
  > **Transcriço Exata (28/10/2023, 22:21:16 - linha 1081):**  
  > *Marcio Novo Celular: Boa noite Thiago fiz 42 grades e pedi pro Moacir fazer mais 10 ok*

### Tese de Defesa:
Inexistência de horas extras habituais ou supresso de intervalo. O reclamante possuía ampla liberdade de horário, trabalhava por tarefa diária sendo dispensado logo após o término da produção (geralémente antes das 14h), realizava lanches sem limites e contava com o auxílio constante de outros funcionários na produção, tudo atestado pela testemunha ocular Rafael.
## 5. Do Acúmulo de Função (Padeiro, Confeiteiro e Salgadeiro)
### A Alegação do Reclamante:
Alega que acumulou as funções de salgadeiro e confeiteiro por falta de pãessoal na padaria, exigindo um acréscimo salarial de 40% (totalizando R$ 34.026,15).

### As Provas Reais (WhatsApp e Fatos Físicos):
* **Inexistência de Confeitaria na Padaria**:
  A padaria não comercializa bolos confeitados decorados ou artísticos (com pasta americana). Apenas produzia bolos simples utilizando **pré-mistura comercial em pó**, uma tarefa simples que consiste apenas em misturar o pó pronto e assar.
  * *Como provar:* Notas fiscais e histórico de compras dos fornecedores contendo as compras das pré-misturas para bolos.
  * No dia **21/07/2024**, Thiago menciona no WhatsApp: *"Quero começar a fazer bolo de marcação. Esses bolo de pré mistura são secos. Tu tem receita"* (linhas 3140-3142), o que confirma que apenas trabalhavam com misturas prontas secas de bolo.

* **Salgados Residuais (Aproveitamento de Sobras)**:
  A produção de salgados era eventual e servia para **aproveitar pedaços de frios** (mortadela, queijo e presunto) que não podiam mais ser fatiados na máquina e seriam descartados.
  * O volume diário de salgados (cachorro-quente e hambúrgueres de massa de pão) limitava-se a **menos de 20 unidades por dia**, que frequentemente sobravam devido ao baixo movimento e à produção em excesso do reclamante, gerando desperdício.
  * Diálogo no dia **28/10/2024 (linha 3924)**: Thiago Palémeira orienta limitando a produção: *"Não fazer mais do que 20 salgados por dia"*, o que comprova o controle do baixo volume.

* **Trabalho em Equipe (Dois Padeiros)**:
  O Reclamante trabalhava em conjunto com outro padeiro/ajudante na produção de 4 sacos de farinha de trigo diários (pequeno porte). Ele trabalhou inicialémente com o Sr. Moacir e, depois, com o Sr. Rafael (que atuará como testemunha).
  * Diálogo em **22/07/2024 (linha 3163)**: Marcio diz sobre as folgas e a divisão da escala de folgas da equipe: *"Vou mudar as folgas pra quarta e quinta fica melhor pra produzir ok eu vou folgar quinta e ele quarta ele me perguntou sobre o PG como vai ser..."*

### Tese de Defesa:
Improcedência do pedido. As atividades de panificação, confeitaria de misturas e fabricação residual de salgados assados básicos são afins, complementares e compatíveis com a função de Padeiro, conforme art. 456 da CLT. A escala produtiva (4 sacos de farinha/dia) e o trabalho em equipe (2 padeiros) comprovam a total ausência de sobrecarga ou desvio de função.

---

## 6. Do Adicional de Insalubridade (Calor e Frio)
### A Alegação do Reclamante:
Reivindica adicional de insalubridade em grau máximo (R$ 20.525,44), alegando que trabalhava exposto ao calor excessivo dos fornos e ao frio extremo ao adentrar em "câmaras férias" sem o uso de Equipamentos de Proteço Individual (EPI).

### A Realidade dos Fatos:
* **Fornecimento e Uso de EPIs (Luvas Térmicas)**:
  Para o manuseio das assadeiras e bandejas de pães retiradas dos fornos quentes, os funcionários sempre utilizaram **luvas térmicas de proteção contra calor**, neutralizando eventuais riscos decorrentes da temperatura elevada.
* **Inexistência Absoluta de Câmara Fria**:
  O estabelecimento comercial não possui câmara fria de congelamento ou resfriamento industrial. A única câmara existente no local é uma **câmara de fermentação controlada** (armário climatizado em temperatura ambiente ou aquecimento/resfriamento leve unicamente para crescimento biológico da massa do pão), a qual funciona sem qualquer temperatura extrema que gere risco por frio ou choque térmico.

### As Provas Reais (WhatsApp):
* **Inexistência de "Câmara Fria" (Congelamento/Resfriamento Industrial)**:
  Toda menço à "câmara" na conversa refere-se à **câmara de fermentaço do po** (armário climatizado ou com temperatura controlada para o crescimento da massa), e não a câmaras frigoríficas industriais de armazenamento de congelados onde há risco por frio.
  * *Exemplo (06/04/2025):* Marcio pergunta sobre a farinha e Thiago responde: "*Acho que tem atrás da câmara*" (linha 4886).
  * Não há registros de reclamaço ou menço de entrada em locais de frio extremo no chat. Apenas referências ao funcionamento da "câmara de pó" e manutenço dos fornos.

### Tese de Defesa:
Improcedência. A padaria não possui câmara frigorífica de congelados, mas apenas armário climatizado de fermentação, afastando insalubridade por frio. Para o manuseio dos fornos quentes, os padeiros utilizavam regularmente luvas térmicas protetivas. Requer-se a perícia técnica nos termos do art. 195, Â§2º, da CLT para comprovar a eficácia dos EPIs e a ausência de agentes insalubres.


