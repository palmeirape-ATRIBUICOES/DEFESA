# MINUTA DE CONTESTAÇÃO TRABALHISTA
*(Documento de rascunho para orientação e uso do Advogado de Defesa)*

**AO JUÍZO DA VARA DO TRABALHO DA COMARCA DE NOVA IGUAÇU/RJ**

**PROCESSO Nº**: 0100545-34.2026.5.01.0222  
**RECLAMANTE**: MARCIO JONE FRANKLIN DE PAULA  
**RECLAMADOS**: MANA PANIFICADORA E COMERCIO LTDA e THIAGO PALMEIRA BARBOSA  

**MANA PANIFICADORA E COMERCIO LTDA**, pessoa jurídica de direito privado, inscrita no CNPJ sob o nº 31.269.546/0001-76, com sede na Rua Capitão Edmundo Soares, 18, Caonze, Nova Iguaçu/RJ, CEP 26250-240; e  
**THIAGO PALMEIRA BARBOSA**, brasileiro, casado, empresário, inscrito no CPF sob o nº 075.283.784-29, residente e domiciliado na [Endereço Completo], por seu advogado infra-assinado, vêm, mui respeitosamente, à presença de Vossa Excelência, apresentar

## CONTESTAÇÃO

à Reclamação Trabalhista movida por **MARCIO JONE FRANKLIN DE PAULA**, com fulcro no artigo 847 da CLT, pelos fatos e fundamentos de direito a seguir expostos.

---

## I. Breve Síntese da Petição Inicial
O Reclamante alega ter sido admitido em 17/04/2023 para exercer a função de Padeiro, com dispensa imotivada em 24/06/2025. Aduz que jamais teve sua CTPS anotada, que percebia salário de R$ 2.200,00 acrescido de R$ 150,00 "por fora" pagos pelo segundo Reclamado, e que sua jornada era das 06h às 15h, sem intervalo para almoço.

Requer o reconhecimento do vínculo, o pagamento de verbas rescisórias integrais no valor estimado de R$ 186.939,89 (sob a alegação de inadimplemento absoluto), acúmulo de função, adicional de insalubridade e indenização por danos morais de R$ 10.000,00.

Entretanto, as alegações da peça exordial distorcem a verdade dos fatos, omitindo a celebração de acordo rescisório extrajudicial plenamente quitado, bem como a iniciativa do próprio trabalhador para que a carteira não fosse registrada, conforme se passa a demonstrar.

---

## II. Do Mérito
### 1. Da Ausência de Anotação da CTPS por Iniciativa do Reclamante - Inexistência de Dano Moral
Embora as Reclamadas não se oponham ao reconhecimento do vínculo no período de 17/04/2023 a 24/06/2025, impugna-se veementemente o pedido de indenização por danos morais decorrentes da falta de registro na CTPS.

Ao contrário do alegado na exordial, **a falta de registro ocorreu por solicitação expressa do Reclamante**. Conforme registros de conversa por WhatsApp anexados (Dossiê de Provas - Mensagens do dia 22/07/2024), o Reclamante solicitou expressamente ao segundo Reclamado que não registrasse seu contrato de trabalho para que o valor correspondente aos encargos previdenciários e tributários da contratação fosse pago "em mãos" diretamente a ele, visando financiar a aquisição de um veículo (modelo Fox 2008) pertencente ao seu tio:

> *"Deixa eu te fazer uma pergunta quanto vc pagaria dr encargos pra assinar minha carteira ?? E que meu tio que me vender um carro (2008) sem entrada parcelas de $700 e dependendo de quanto for esse encargos se vc pudesse me dar em maos em interaria ( e eu faria uma autonomia e pagaria a parte ) se vc puder fazer esse esquema me ajudaria muito"* (Mensagem do Reclamante em 22/07/2024).

Admitir que o trabalhador solicite o não registro para auferir vantagens financeiras em mãos e, posteriormente, acione a Justiça do Trabalho pleiteando indenização por danos morais decorrentes dessa mesma informalidade viola o princípio da **boa-fé objetiva** (*venire contra factum proprium*), configurando manifesto abuso de direito.

Desta forma, requer-se a improcedência do pedido de indenização por danos morais.

---

### 2. Da Efetiva Quitação das Verbas Rescisórias - Acordo Extrajudicial e Compensação de Valores
O Reclamante atua em flagrante má-fé ao afirmar na petição inicial que foi dispensado sem receber "nenhum de seus direitos garantidos por lei". 

A realidade é que, no dia **06/07/2025**, as partes transacionaram a rescisão do contrato de trabalho, estabelecendo as verbas rescisórias devidas no valor bruto de **R$ 12.852,44**, abrangendo:
* Saldo de salário (24 dias): R$ 1.600,00
* Férias vencidas e proporcionais (2023/24, 2024/25 e 2/12 avos) + 1/3 constitucional: R$ 5.777,77
* 13º salário proporcional (6/12 avos): R$ 1.000,00
* Aviso prévio indenizado (6 dias): R$ 400,00
* FGTS indenizado: R$ 4.341,33

O Reclamante assinou o respectivo termo de rescisão e quitação (conforme documento em anexo - *00004486-PHOTO-2025-07-06-21-50-20.jpg*), declarando o recebimento integral da referida quantia.

O pagamento deu-se por meio de compensação de mútuo (abatimento do valor de R$ 5.000,00 adiantados pelas Reclamadas para a compra do carro do Reclamante e outros adiantamentos combinados) e o saldo de **R$ 1.000,00** foi pago através de transferência bancária via Pix no dia **06/07/2025, às 22:11:13** (conforme comprovante de transação anexo).

Portanto, resta demonstrada a quitação das verbas pleiteadas. Sucessivamente, caso este juízo entenda por recalcular as verbas contratuais, requer-se a **compensação/dedução integral dos R$ 12.852,44** comprovadamente quitados, sob pena de enriquecimento sem causa do obreiro (*bis in idem*), nos termos do art. 377 do Código Civil e art. 767 da CLT.

---

### 3. Da Inexistência de Horas Extras e de Intervalo Intrajornada Suprimido
O Reclamante sustenta que ativava-se em jornada rígida das 06h às 15h, sem intervalo. A alegação não condiz com a rotina de trabalho.

Primeiramente, o Reclamante exercia suas atividades de forma flexível e autônoma na produção de pães. Em **06/02/2024**, o próprio obreiro solicitou autorização para alterar seu horário de trabalho para realizar outros serviços autônomos de pintura/biscate na parte da manhã, passando a ingressar na padaria às 09h e saindo às 14h:

> *"Vou fazer um biscatinho aqui perto de casa de 6 as oito posso chegar lá umas 9:00 da manhã eu fico até 14:00 Pode ser ??"* (Mensagem do Reclamante em 06/02/2024).

Ademais, o histórico de conversas revela que o Reclamante possuía folgas regulares semanais e gozava de intervalos intrajornada comuns de mercado, não estando submetido a qualquer vigilância ou controle rígido que impedisse sua alimentação. Ademais, a produção era compartilhada com outros ajudantes e padeiros da equipe (como os Srs. Moacir e Rafael), o que reduzia a intensidade do labor diário.

Logo, indevido o pagamento de horas extras e reflexos.

---

### 4. Da Ausência de Acúmulo de Função
Pleiteia o Reclamante um adicional de 40% sob a alegação de acúmulo das funções de salgadeiro e confeiteiro. 

O pedido é manifestamente improcedente:
1. **Pessoal Dedicado**: A padaria contava com confeiteiros contratados especificamente para tal finalidade, conforme indicam os registros de contratação dos Srs. Carlos (Confeiteiro) e Sra. Kayti (Confeiteira) no período contratual.
2. **Volume Residual**: A produção eventual de salgados pelo Reclamante era de escala ínfima, limitada expressamente por determinação da gerência a no máximo 20 salgados diários, o que afasta qualquer alegação de sobrecarga ou desvio funcional.
3. **Compatibilidade Legal**: A elaboração de massas correlatas (pães e salgados básicos) insere-se no dever de colaboração mútua do trabalhador, sendo perfeitamente compatível com a função de padeiro, atraindo a incidência do art. 456, parágrafo único, da CLT.

---

### 5. Do Adicional de Insalubridade
O Reclamante fundamenta o pedido de insalubridade sob a falsa premissa de que adentrava em "câmaras frias" industriais.

As Reclamadas esclarecem que o estabelecimento comercial não possui câmara fria frigorífica de congelamento, mas tão somente **câmara de fermentação controlada** (armário de climatização cuja finalidade é apenas acelerar ou retardar o crescimento biológico da massa do pão), operando em temperaturas próximas à temperatura ambiente ou resfriamento leve que não geram condições insalubres de frio.

Outrossim, impugnam-se as alegações quanto à exposição ao calor excessivo sem EPIs, requerendo-se a realização de perícia técnica nos termos do art. 195, §2º, da CLT.

---

## III. Da Litigância de Má-Fé do Reclamante
O comportamento do Reclamante neste processo atenta contra a dignidade da Justiça. O obreiro alterou deliberadamente a verdade dos fatos ao omitir o recebimento de **R$ 12.852,44** na rescisão, alegando inadimplemento total das verbas rescisórias, mesmo ciente de que havia assinado o recibo de quitação e recebido as compensações e transferências via Pix.

A conduta do Reclamante amolda-se perfeitamente às hipóteses descritas no artigo 793-B, incisos I e II, da CLT (correspondente ao art. 80, I e II, do CPC).

Desta forma, requer-se a condenação do Reclamante ao pagamento de multa por litigância de má-fé, em favor das Reclamadas, no patamar máximo legal, além de indenização pelos prejuízos e honorários advocatícios decorrentes da defesa forçada.

---

## IV. Dos Requerimentos
Diante de todo o exposto, as Reclamadas requerem:
1. O acolhimento da presente defesa para julgar **totalmente improcedentes** os pedidos da Reclamação Trabalhista, à exceção do mero registro do vínculo já reconhecido pelas partes;
2. Subsidiariamente, na remota hipótese de condenação, requer-se a **compensação/dedução integral** do valor de **R$ 12.852,44** comprovadamente adiantado e quitado à época da rescisão, evitando-se o enriquecimento ilícito do obreiro;
3. A condenação do Reclamante ao pagamento de multa por **Litigância de Má-Fé**, nos termos dos arts. 793-B e 793-C da CLT;
4. A condenação do Reclamante ao pagamento de honorários advocatícios sucumbenciais no percentual de 15% sobre os pedidos julgados improcedentes, conforme art. 791-A da CLT;
5. A produção de todas as provas em direito admitidas, especialmente o depoimento pessoal do Reclamante, sob pena de confissão, oitiva de testemunhas e a juntada do arquivo eletrônico da conversa de WhatsApp e comprovantes bancários anexos.

Nesses termos,  
Pede deferimento.

Nova Iguaçu, __ de __________ de 2026.

______________________________________  
**Nome do Advogado**  
OAB/RJ nº _______  
